<?php
/**
 * Plugin Name:       Gravity Forms Email Subject URL
 * Description:       Adds the URL of the website to any gravity form submissions
 * Version:           1.0.0
 * Author:            Ryan Lyons
 * License:			  GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

function gf_add_url_to_subject($notification, $form, $entry) {
    $site_url = get_bloginfo('url');

    $notification['subject'] = '[' . $site_url . '] ' . $notification['subject'];

    return $notification;
}
add_filter('gform_notification', 'gf_add_url_to_subject', 10, 3);
