<?php
/**
 * Plugin Name:       Plexamedia Email Subject URL
 * Description:       Adds the URL of the website to any gravity form submissions
 * Version:           1.0.0
 * Author:            Plexamedia - Ryan Lyons
 * Author URI:        https://plexamedia.com
 * License:			  GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Adds the website URL to the subject of Gravity Forms notifications.
 */
function plexa_add_url_to_subject($notification, $form, $entry) {
    $site_url = get_bloginfo('url');

    $notification['subject'] = '[' . $site_url . '] ' . $notification['subject'];

    return $notification;
}
add_filter('gform_notification', 'plexa_add_url_to_subject', 10, 3);
